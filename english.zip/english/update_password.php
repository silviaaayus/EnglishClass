<?php
require_once('koneksi.php');
class emp{
    
}
header('Content-Type: application/json');

$siswa_password = $_POST['siswa_password'];
$siswa_id = $_POST['siswa_id'];



$query = "UPDATE `tb_siswa` SET `siswa_password` = '$siswa_password' WHERE siswa_id ='$siswa_id'";
$ad = mysqli_query($con, $query);

if ($ad) {
   
    $response = new emp();
    $response->response = "Sukses ";
    $response->code = 1;
    die(json_encode($response));
} else {
    $response = new emp();
    $response->response = "Gagal !";
    $response->code = 0;
    die(json_encode($response));
}


mysqli_close($con);
