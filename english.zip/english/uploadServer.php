<?php

    $file_path = "upload_suara/";
     
    $file_path = $file_path . basename( $_FILES['suara']['name']);
    if(move_uploaded_file($_FILES['suara']['tmp_name'], $file_path)) {
        $response = [];
    $response["status"] = 1;
    $response["message"] = "Okk";
    } else{
        $response = [];
    $response["status"] = 0;
    $response["message"] = "Jaringan Bermasalah";
    }

    echo json_encode($response);
 ?>