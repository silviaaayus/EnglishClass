<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'laravel_english_class');
$con = mysqli_connect(HOST, USER, PASS, DB) or die('Unable to Connect');
