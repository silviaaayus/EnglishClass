<?php
require_once('koneksi.php');
header('Content-Type: application/json');


$siswa_id = $_GET['siswa_id'];


$perintah = "SELECT * FROM tb_meeting_skor
LEFT JOIN tb_meeting_materi ON tb_meeting_materi.meeting_materi_id = tb_meeting_skor.meeting_materi_id
LEFT JOIN tb_meeting ON tb_meeting.meeting_id = tb_meeting_materi.meeting_id
 WHERE tb_meeting_skor.siswa_id = '$siswa_id'";

$eksekusi = mysqli_query($con, $perintah);
$cek = mysqli_affected_rows($con);

if ($cek > 0) {
    $response["status"] = 'sukses';
    $response["pesan"] = "Data tersedia";
    $response["res"] = array();
    $F = array();
    while ($ambil = mysqli_fetch_object($eksekusi)) {
        $F[] = $ambil;
    }
    $response["res"] = $F;
} else {
   $response["status"] = 'Gagal';
    $response["pesan"] = "Data Tak tersedia";

}
echo json_encode($response);
mysqli_close($con);
?>