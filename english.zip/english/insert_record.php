<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo $_SERVER["DOCUMENT_ROOT"];  // /home1/demonuts/public_html
    //including the database connection file
    require_once('koneksi.php');
 
    $siswa_id = $_GET['siswa_id'];  
    $meeting_materi_id = $_GET['meeting_materi_id'];  
    $meeting_record_tipe = $_GET['meeting_record_tipe'];  
  

  

    $originalImgName = $_FILES['suara']['name'];
    $tempName = $_FILES['suara']['tmp_name'];
    $folder = "upload_suara/";
    // $url = "http://192.168.100.15/sipula/" . $originalImgName; //update path as per your directory structure 

    if (move_uploaded_file($tempName, $folder . $originalImgName)) {
        $query = "INSERT INTO `laravel_english_class`.`tb_meeting_record` (`meeting_materi_id`, `siswa_id`, `meeting_record_tipe`, `meeting_record_audio`, `meeting_record_nilai`, `created_at`, `updated_at`) 
        VALUES ('$meeting_materi_id', '$siswa_id', '$meeting_record_tipe', '$originalImgName', NULL, NULL, NULL)";
        if (mysqli_query($con, $query)) {            
          
               echo json_encode(array("status" => "true", "message" => "Successfully file added!"));
           
           
        } else {
            echo json_encode(array("status" => "false", "message" => "Failed!"));
        }
        //echo "moved to ".$url;
    } else {
        echo json_encode(array("status" => "false", "message" => "Failed!"));
    }
}