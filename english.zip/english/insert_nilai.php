<?php
require_once('koneksi.php');
class emp{
    
}
header('Content-Type: application/json');

$meeting_materi_id = $_POST['meeting_materi_id'];
$siswa_id = $_POST['siswa_id'];
$skor = $_POST['skor'];


$query = "INSERT INTO `tb_meeting_skor` (`meeting_skor_id`, `meeting_materi_id`, `siswa_id`, `skor`) VALUES (NULL,'$meeting_materi_id', '$siswa_id', '$skor')";
$ad = mysqli_query($con, $query);

if ($ad) {
   
    $response = new emp();
    $response->response = "Sukses ";
    $response->code = 1;
    die(json_encode($response));
} else {
    $response = new emp();
    $response->response = "Gagal !. Silahkan coba lagi. 2";
    $response->code = 0;
    die(json_encode($response));
}


mysqli_close($con);
