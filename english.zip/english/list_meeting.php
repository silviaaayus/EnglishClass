<?php
require_once('koneksi.php');
header('Content-Type: application/json');

$dosen_id = $_GET['dosen_id'];

$perintah = "SELECT * FROM tb_meeting 
LEFT JOIN tb_dosen ON tb_dosen.dosen_id = tb_meeting.dosen_id 
LEFT JOIN tb_siswa ON tb_siswa.dosen_id = tb_meeting.dosen_id 
WHERE tb_meeting.meeting_status = 'Aktif' AND tb_meeting.dosen_id = '$dosen_id' ORDER BY tb_meeting.meeting_id";

$eksekusi = mysqli_query($con, $perintah);
$cek = mysqli_affected_rows($con);

if ($cek > 0) {
    $response["status"] = 'sukses';
    $response["pesan"] = "Data tersedia";
    $response["res"] = array();
    $F = array();
    while ($ambil = mysqli_fetch_object($eksekusi)) {
        $F[] = $ambil;
    }
    $response["res"] = $F;
} else {
   $response["status"] = 'Gagal';
    $response["pesan"] = "Data Tak tersedia";

}
echo json_encode($response);
mysqli_close($con);
?>